#ifndef LENOKOR_TIMER_H
#define LENOKOR_TIMER_H

void timer_init(void);
unsigned long timer_uptime_seconds(void);

#endif