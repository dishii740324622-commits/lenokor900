#ifndef LENOKOR_LOG_H
#define LENOKOR_LOG_H

void log_info(const char *message);
void log_warn(const char *message);
void log_error(const char *message);

#endif