#ifndef LENOKOR_PANIC_H
#define LENOKOR_PANIC_H

__attribute__((noreturn)) void kernel_panic(const char *reason);
__attribute__((noreturn)) void kernel_exception(unsigned long vector,
                                                 unsigned long esr,
                                                 unsigned long elr,
                                                 unsigned long far);

#endif