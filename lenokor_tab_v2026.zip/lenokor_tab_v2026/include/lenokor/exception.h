#ifndef LENOKOR_EXCEPTION_H
#define LENOKOR_EXCEPTION_H

void exception_init(void);
void exception_dispatch(unsigned long vector, unsigned long esr,
                        unsigned long elr, unsigned long far);

#endif