#ifndef LENOKOR_CONSOLE_H
#define LENOKOR_CONSOLE_H

void console_init(void);
void console_clear(void);
void console_putc(char value);
void console_write(const char *text);
char console_getc(void);

#endif