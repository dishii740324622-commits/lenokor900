#ifndef LENOKOR_SHELL_H
#define LENOKOR_SHELL_H

__attribute__((noreturn)) void shell_run(void);

#endif