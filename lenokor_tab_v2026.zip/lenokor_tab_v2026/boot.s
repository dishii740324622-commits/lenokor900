.section ".text.boot"

.global _start
.type _start, %function
.extern kernel_main

_start:
    mrs     x0, mpidr_el1
    and     x0, x0, #0xFFFFFF
    cbnz    x0, halt

    adrp    x0, __stack_top
    add     x0, x0, :lo12:__stack_top
    mov     sp, x0

    adrp    x0, __bss_start
    add     x0, x0, :lo12:__bss_start
    adrp    x1, __bss_end
    add     x1, x1, :lo12:__bss_end
clear_bss:
    cmp     x0, x1
    b.hs    call_kernel
    str     xzr, [x0], #8
    b       clear_bss

call_kernel:
    bl      kernel_main

halt:
    wfe
    b       halt

.size _start, . - _start
hang:
    b       hang