#include <lenokor/console.h>

#define PL011_BASE 0x09000000UL
#define PL011_DR 0x00UL
#define PL011_FR 0x18UL
#define PL011_IBRD 0x24UL
#define PL011_FBRD 0x28UL
#define PL011_LCRH 0x2CUL
#define PL011_CR 0x30UL
#define PL011_IMSC 0x38UL
#define PL011_FR_RXFE (1U << 4)
#define PL011_FR_TXFF (1U << 5)

static volatile unsigned int *pl011_register(unsigned long offset)
{
    return (volatile unsigned int *)(PL011_BASE + offset);
}

void pl011_init(void)
{
    *pl011_register(PL011_CR) = 0;
    *pl011_register(PL011_IMSC) = 0;
    *pl011_register(PL011_IBRD) = 13;
    *pl011_register(PL011_FBRD) = 1;
    *pl011_register(PL011_LCRH) = (3U << 5) | (1U << 4);
    *pl011_register(PL011_CR) = (1U << 9) | (1U << 8) | 1U;
}

void pl011_putc(char value)
{
    while ((*pl011_register(PL011_FR) & PL011_FR_TXFF) != 0) {
    }

    *pl011_register(PL011_DR) = (unsigned int)value;
}

char pl011_getc(void)
{
    while ((*pl011_register(PL011_FR) & PL011_FR_RXFE) != 0) {
    }

    return (char)(*pl011_register(PL011_DR) & 0xFFU);
}