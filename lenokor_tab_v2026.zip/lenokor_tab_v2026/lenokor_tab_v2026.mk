# Inherit from core AOSP tablet configs
$(call inherit-product, $(SRC_TARGET_DIR)/product/full_base.mk)

# Product Information
PRODUCT_NAME := lenokor_tab_v2026
PRODUCT_DEVICE := lenokor_tab_v2026
PRODUCT_BRAND := Lenokor
PRODUCT_MODEL := Lenokor Tab OS 2026
PRODUCT_MANUFACTURER := Lenokor

# Lynocore OS System Properties
PRODUCT_PROPERTY_OVERRIDES += \
    ro.lenokor.version=2026.1 \
    ro.lenokor.build.type=official \
    ro.build.display.id=Lenokor-OS-v2026