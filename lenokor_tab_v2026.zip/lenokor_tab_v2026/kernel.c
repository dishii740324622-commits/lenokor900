#include <lenokor/console.h>
#include <lenokor/exception.h>
#include <lenokor/log.h>
#include <lenokor/shell.h>
#include <lenokor/timer.h>

void kernel_main(void)
{
    console_init();
    exception_init();
    timer_init();

    console_clear();
    log_info("Lenokor kernel starting");
    log_info("Architecture: AArch64 | Platform: QEMU virt");
    log_info("Kernel initialized; interactive console ready");
    shell_run();
}