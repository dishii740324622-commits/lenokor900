#include <lenokor/exception.h>
#include <lenokor/panic.h>

extern char exception_vectors[];

void exception_init(void)
{
    __asm__ volatile("msr vbar_el1, %0\n"
                     "dsb sy\n"
                     "isb\n"
                     :
                     : "r"(exception_vectors)
                     : "memory");
}

void exception_dispatch(unsigned long vector, unsigned long esr,
                        unsigned long elr, unsigned long far)
{
    kernel_exception(vector, esr, elr, far);
}