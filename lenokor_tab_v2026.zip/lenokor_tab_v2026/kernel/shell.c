#include <lenokor/console.h>
#include <lenokor/log.h>
#include <lenokor/shell.h>
#include <lenokor/timer.h>

#define INPUT_CAPACITY 128U

static const char prompt[] = "lenokor> ";

static int strings_equal(const char *left, const char *right)
{
    while (*left != '\0' && *left == *right) {
        ++left;
        ++right;
    }

    return *left == '\0' && *right == '\0';
}

static void print_unsigned(unsigned long value)
{
    char digits[20];
    unsigned int length = 0;

    if (value == 0) {
        console_putc('0');
        return;
    }

    while (value != 0 && length < sizeof(digits)) {
        digits[length++] = (char)('0' + (value % 10UL));
        value /= 10UL;
    }

    while (length != 0) {
        console_putc(digits[--length]);
    }
}

static void print_help(void)
{
    console_write("Commands:\n");
    console_write("  help       Show available commands\n");
    console_write("  version    Show kernel version\n");
    console_write("  uptime     Show time since boot\n");
    console_write("  clear      Clear the terminal\n");
    console_write("  echo TEXT  Print TEXT\n");
}

static void run_command(char *line)
{
    while (*line == ' ' || *line == '\t') {
        ++line;
    }

    if (*line == '\0') {
        return;
    }

    if (strings_equal(line, "help")) {
        print_help();
    } else if (strings_equal(line, "version")) {
        console_write("Lenokor kernel 0.1.0 (AArch64)\n");
    } else if (strings_equal(line, "uptime")) {
        console_write("Uptime: ");
        print_unsigned(timer_uptime_seconds());
        console_write(" seconds\n");
    } else if (strings_equal(line, "clear")) {
        console_clear();
    } else if (line[0] == 'e' && line[1] == 'c' && line[2] == 'h' &&
               line[3] == 'o' && (line[4] == ' ' || line[4] == '\t')) {
        console_write(line + 5);
        console_putc('\n');
    } else {
        log_warn("Unknown command. Type 'help' for a list.");
    }
}

static void read_line(char *buffer, unsigned int capacity)
{
    unsigned int length = 0;

    for (;;) {
        char value = console_getc();

        if (value == '\r' || value == '\n') {
            console_putc('\n');
            buffer[length] = '\0';
            return;
        }

        if (value == '\b' || value == 0x7F) {
            if (length != 0) {
                --length;
                console_write("\b \b");
            }
            continue;
        }

        if (value >= 0x20 && value < 0x7F && length + 1U < capacity) {
            buffer[length++] = value;
            console_putc(value);
        }
    }
}

__attribute__((noreturn)) void shell_run(void)
{
    char input[INPUT_CAPACITY];

    console_write("Type 'help' to see available commands.\n\n");
    for (;;) {
        console_write(prompt);
        read_line(input, sizeof(input));
        run_command(input);
    }
}