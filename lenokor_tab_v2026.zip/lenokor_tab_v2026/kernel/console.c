#include <lenokor/console.h>

void pl011_init(void);
void pl011_putc(char value);
char pl011_getc(void);

void console_init(void)
{
    pl011_init();
}

void console_putc(char value)
{
    if (value == '\n') {
        pl011_putc('\r');
    }

    pl011_putc(value);
}

void console_write(const char *text)
{
    while (*text != '\0') {
        console_putc(*text++);
    }
}

char console_getc(void)
{
    return pl011_getc();
}

void console_clear(void)
{
    console_write("\033[2J\033[H");
}