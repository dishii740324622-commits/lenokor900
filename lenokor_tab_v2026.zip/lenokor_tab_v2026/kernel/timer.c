#include <lenokor/timer.h>

static unsigned long counter_frequency;
static unsigned long boot_counter;

static unsigned long read_counter(void)
{
    unsigned long value;
    __asm__ volatile("mrs %0, cntpct_el0" : "=r"(value));
    return value;
}

void timer_init(void)
{
    __asm__ volatile("mrs %0, cntfrq_el0" : "=r"(counter_frequency));
    boot_counter = read_counter();
}

unsigned long timer_uptime_seconds(void)
{
    if (counter_frequency == 0) {
        return 0;
    }

    return (read_counter() - boot_counter) / counter_frequency;
}