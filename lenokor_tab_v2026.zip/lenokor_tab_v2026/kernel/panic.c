#include <lenokor/console.h>
#include <lenokor/log.h>
#include <lenokor/panic.h>

static void write_hex(unsigned long value)
{
    static const char digits[] = "0123456789ABCDEF";
    int shift;

    console_write("0x");
    for (shift = (int)(sizeof(value) * 8U) - 4; shift >= 0; shift -= 4) {
        console_putc(digits[(value >> shift) & 0xFU]);
    }
}

__attribute__((noreturn)) void kernel_panic(const char *reason)
{
    log_error("KERNEL PANIC");
    log_error(reason);

    for (;;) {
        __asm__ volatile("msr daifset, #0xF\nwfe");
    }
}

__attribute__((noreturn)) void kernel_exception(unsigned long vector,
                                                 unsigned long esr,
                                                 unsigned long elr,
                                                 unsigned long far)
{
    log_error("Unhandled CPU exception");
    console_write("vector=");
    write_hex(vector);
    console_write(" esr=");
    write_hex(esr);
    console_write(" elr=");
    write_hex(elr);
    console_write(" far=");
    write_hex(far);
    console_putc('\n');
    kernel_panic("CPU halted after exception");
}