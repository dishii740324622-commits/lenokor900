#include <lenokor/console.h>
#include <lenokor/log.h>

static void log_message(const char *level, const char *color,
                        const char *message)
{
    console_write(color);
    console_write("[");
    console_write(level);
    console_write("]\033[0m ");
    console_write(message);
    console_putc('\n');
}

void log_info(const char *message)
{
    log_message("INFO", "\033[32m", message);
}

void log_warn(const char *message)
{
    log_message("WARN", "\033[33m", message);
}

void log_error(const char *message)
{
    log_message("ERROR", "\033[31m", message);
}