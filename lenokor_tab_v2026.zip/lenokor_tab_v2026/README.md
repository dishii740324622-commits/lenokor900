# Lenokor OS

Lenokor is a freestanding AArch64 operating-system project. The current target
is the QEMU `virt` machine; it is not an Android ROM and is not yet a tablet
image.

## Current kernel

- AArch64 startup and linker-defined kernel layout
- PL011 serial console with input and output
- Interactive command shell (`help`, `version`, `uptime`, `clear`, `echo`)
- Colored kernel log levels
- CPU exception vector table and fatal exception diagnostics
- Architectural counter-based uptime

## Build and run

The build requires Clang, LLVM's `ld.lld`, GNU Make, and QEMU's AArch64 system
emulator. On macOS with Homebrew:

```sh
brew install llvm qemu
export PATH="$(brew --prefix llvm)/bin:$PATH"
make clean all
make run
```

The serial console is interactive. Use `Ctrl-A`, then `X` to exit QEMU.

## Roadmap

1. Parse the QEMU device tree and discover RAM and hardware devices.
2. Add page-frame allocation, virtual memory, and a kernel heap.
3. Configure the GIC and generic timer for interrupt-driven scheduling.
4. Add tasks, context switching, and a system-call boundary.
5. Add a VFS, an initramfs, and user-space processes.
6. Add storage, networking, and a graphical display stack.

These are separate kernel subsystems, not features supplied by the current
serial-shell build. Hardware support and a flashable image require a specific
device target and its firmware interfaces.

## Android 14 battery video app

`android-app` is a separate installable Android application. It uses the
existing `bootloader/battery_low.mp4` asset, shows a notification when Android
starts with a low battery or broadcasts a low-battery event, and plays the clip
for exactly four seconds when the user opens the notification or app while the
battery is at or below 15 percent. The app must be opened once and notification
permission granted on Android 13 and later.

Android restricts apps from launching activities over the lock screen or
booting UI from the background. Consequently this APK cannot play before
Android starts, while the device is fully powered off, or universally replace
vendor bootloader/charging animations. Those behaviors require a custom ROM
and device-specific boot and charging support.

Build the APK with Android Studio or Gradle using JDK 17 and Android SDK 35:

```sh
cd android-app
gradle assembleDebug
```

The debug APK is written to `android-app/app/build/outputs/apk/debug/app-debug.apk`.