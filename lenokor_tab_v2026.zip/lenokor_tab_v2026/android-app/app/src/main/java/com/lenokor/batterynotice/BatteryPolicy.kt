package com.lenokor.batterynotice

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager

object BatteryPolicy {
    const val LOW_BATTERY_PERCENT = 15

    fun currentPercent(context: Context): Int? {
        val status = context.registerReceiver(
            null,
            IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        ) ?: return null

        val level = status.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = status.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
        if (level < 0 || scale <= 0) return null

        return level * 100 / scale
    }

    fun isLow(context: Context): Boolean =
        (currentPercent(context) ?: 100) <= LOW_BATTERY_PERCENT
}