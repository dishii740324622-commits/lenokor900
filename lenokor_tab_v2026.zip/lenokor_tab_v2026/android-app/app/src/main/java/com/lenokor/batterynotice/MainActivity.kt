package com.lenokor.batterynotice

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.app.WallpaperManager
import android.graphics.Color
import android.graphics.BitmapFactory
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity(), SurfaceHolder.Callback {
    private val handler = Handler(Looper.getMainLooper())
    private var mediaPlayer: MediaPlayer? = null
    private var closeAfterPlayback = false
    private lateinit var surfaceView: SurfaceView

    private val stopPlayback = Runnable {
        releasePlayer()
        if (closeAfterPlayback) {
            finish()
        } else {
            showHome()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        }

        if (BatteryPolicy.isLow(this)) {
            startPlayback(closeWhenDone = true)
        } else {
            showHome()
        }
    }

    private fun showHome() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 32, 32, 32)
            setBackgroundColor(Color.rgb(16, 21, 18))
        }

        val title = TextView(this).apply {
            text = "Lenokor Battery Notice"
            textSize = 26f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        val percent = BatteryPolicy.currentPercent(this)
        val status = TextView(this).apply {
            text = if (percent == null) {
                "Battery status is unavailable."
            } else {
                "Battery: $percent%\nThe warning triggers at ${BatteryPolicy.LOW_BATTERY_PERCENT}% or lower."
            }
            textSize = 16f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 20, 0, 24)
        }
        val preview = Button(this).apply {
            text = "Preview 4-second video"
            setOnClickListener { startPlayback(closeWhenDone = false) }
        }
        val alerts = Button(this).apply {
            text = if (notificationsAllowed()) "Low-battery alerts enabled" else "Enable low-battery alerts"
            isEnabled = !notificationsAllowed()
            setOnClickListener { requestNotificationPermission() }
        }
        val chrome = Button(this).apply {
            text = "Open Google Chrome"
            setOnClickListener { openChrome() }
        }
        val wallpaper = Button(this).apply {
            text = "Apply wallpaper to Home and Lock screens"
            setOnClickListener { applySystemWallpaper() }
        }

        root.addView(title)
        root.addView(status)
        root.addView(preview)
        root.addView(alerts)
        root.addView(chrome)
        root.addView(wallpaper)
        setContentView(root)
    }

    private fun applySystemWallpaper() {
        try {
            val bitmap = assets.open("orange wallpeper.jpeg").use {
                BitmapFactory.decodeStream(it)
            } ?: throw IllegalStateException("Wallpaper image could not be decoded")

            WallpaperManager.getInstance(this).setBitmap(
                bitmap,
                null,
                true,
                WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK
            )
            bitmap.recycle()
            Toast.makeText(this, "Wallpaper applied to Home and Lock screens", Toast.LENGTH_LONG).show()
        } catch (_: Exception) {
            Toast.makeText(this, "Could not apply wallpaper", Toast.LENGTH_LONG).show()
        }
    }

    private fun openChrome() {
        val chromeIntent = packageManager.getLaunchIntentForPackage("com.android.chrome")
        if (chromeIntent != null) {
            startActivity(chromeIntent)
            return
        }

        val marketIntent = Intent(
            Intent.ACTION_VIEW,
            Uri.parse("market://details?id=com.android.chrome")
        )
        try {
            startActivity(marketIntent)
        } catch (_: Exception) {
            startActivity(
                Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse("https://play.google.com/store/apps/details?id=com.android.chrome")
                )
            )
        }
    }

    private fun notificationsAllowed(): Boolean =
        Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) ==
        PackageManager.PERMISSION_GRANTED

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && !notificationsAllowed()) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 34)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 34) showHome()
    }

    private fun startPlayback(closeWhenDone: Boolean) {
        closeAfterPlayback = closeWhenDone
        surfaceView = SurfaceView(this)
        surfaceView.setBackgroundColor(Color.BLACK)
        surfaceView.holder.addCallback(this)
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            )
        setContentView(surfaceView)
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        val player = MediaPlayer()
        mediaPlayer = player
        try {
            assets.openFd("battery_low.mp4").use { clip ->
                player.setDataSource(clip.fileDescriptor, clip.startOffset, clip.length)
            }
            player.setSurface(holder.surface)
            player.setVolume(0f, 0f)
            player.isLooping = true
            player.setOnPreparedListener {
                it.start()
                handler.postDelayed(stopPlayback, 4_000L)
            }
            player.setOnErrorListener { _, _, _ ->
                handler.removeCallbacks(stopPlayback)
                releasePlayer()
                showHome()
                true
            }
            player.prepareAsync()
        } catch (_: Exception) {
            releasePlayer()
            showHome()
        }
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) = Unit

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        handler.removeCallbacks(stopPlayback)
        releasePlayer()
    }

    private fun releasePlayer() {
        mediaPlayer?.setOnPreparedListener(null)
        mediaPlayer?.setOnErrorListener(null)
        mediaPlayer?.release()
        mediaPlayer = null
    }

    override fun onDestroy() {
        handler.removeCallbacks(stopPlayback)
        releasePlayer()
        super.onDestroy()
    }
}