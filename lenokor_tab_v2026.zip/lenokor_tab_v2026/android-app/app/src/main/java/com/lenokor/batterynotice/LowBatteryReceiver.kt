package com.lenokor.batterynotice

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class LowBatteryReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            Intent.ACTION_BATTERY_LOW -> LowBatteryNotification.show(context)
            Intent.ACTION_BOOT_COMPLETED -> {
                if (BatteryPolicy.isLow(context)) {
                    LowBatteryNotification.show(context)
                }
            }
        }
    }
}